
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

// Structure for Huffman Tree Node
struct Node
{
    char ch;
    int freq;
    Node *left, *right;

    Node(char c, int f)
    {
        ch = c;
        freq = f;
        left = right = NULL;
    }
};

// Greedy comparator
struct Compare
{
    bool operator()(Node* a, Node* b)
    {
        return a->freq > b->freq;
    }
};

// Generate Huffman Codes
void printCodes(Node* root, string code)
{
    if (root == NULL)
        return;

    if (root->left == NULL && root->right == NULL)
    {
        cout << root->ch << " : " << code << endl;
        return;
    }

    printCodes(root->left, code + "0");
    printCodes(root->right, code + "1");
}

int main()
{
    int n;
    char ch;
    int freq;

    priority_queue<Node*, vector<Node*>, Compare> pq;

    cout << "Enter number of characters: ";
    cin >> n;

    cout << "Enter character and frequency:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> ch >> freq;
        pq.push(new Node(ch, freq));
    }

    // Build Huffman Tree using Greedy Strategy
    while (pq.size() > 1)
    {
        Node* left = pq.top();
        pq.pop();

        Node* right = pq.top();
        pq.pop();

        Node* newNode = new Node('$',left->freq + right->freq);

        newNode->left = left;
        newNode->right = right;

        pq.push(newNode);
    }

    cout << "\nHuffman Codes:\n";
    printCodes(pq.top(), "");

    return 0;
}
