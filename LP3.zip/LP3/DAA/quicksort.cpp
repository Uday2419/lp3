
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

// Swap two elements
void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

// Deterministic Partition (Last element as pivot)
int partitionDeterministic(int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;
            swap(arr[i], arr[j]);
        }
    }

    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// Deterministic Quick Sort
void quickSortDeterministic(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partitionDeterministic(arr, low, high);

        quickSortDeterministic(arr, low, pi - 1);
        quickSortDeterministic(arr, pi + 1, high);
    }
}

// Randomized Partition
int partitionRandomized(int arr[], int low, int high)
{
    int randomIndex = low + rand() % (high - low + 1);

    swap(arr[randomIndex], arr[high]);

    return partitionDeterministic(arr, low, high);
}

// Randomized Quick Sort
void quickSortRandomized(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partitionRandomized(arr, low, high);

        quickSortRandomized(arr, low, pi - 1);
        quickSortRandomized(arr, pi + 1, high);
    }
}

// Display array
void display(int arr[], int n)
{
    for (int i = 0; i < n; i++)
        cout << arr[i] << " ";

    cout << endl;
}

int main()
{
    int n;

    cout << "Enter number of elements: ";
    cin >> n;

    int arr1[n], arr2[n];

    cout << "Enter array elements:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> arr1[i];
        arr2[i] = arr1[i];
    }

    // Deterministic Quick Sort
    quickSortDeterministic(arr1, 0, n - 1);

    cout << "\nDeterministic Quick Sort:\n";
    display(arr1, n);

    // Randomized Quick Sort
    srand(time(0));
    quickSortRandomized(arr2, 0, n - 1);

    cout << "\nRandomized Quick Sort:\n";
    display(arr2, n);

    return 0;
}
