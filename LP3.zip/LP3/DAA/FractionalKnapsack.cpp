
#include <iostream>
#include <algorithm>
using namespace std;

struct Item
{
    int profit, weight;
    double ratio;
};

bool compare(Item a, Item b)
{
    return a.ratio > b.ratio;
}

int main()
{
    int n, capacity;
    double totalProfit = 0;

    cout << "Enter number of items: ";
    cin >> n;

    Item items[n];

    cout << "Enter profit and weight of each item:\n";

    for (int i = 0; i < n; i++)
    {
        cin >> items[i].profit >> items[i].weight;
        items[i].ratio = (double)items[i].profit /
                         items[i].weight;
    }

    cout << "Enter knapsack capacity: ";
    cin >> capacity;

    // Sort items by profit/weight ratio
    sort(items, items + n, compare);

    for (int i = 0; i < n; i++)
    {
        if (capacity == 0)
            break;

        if (items[i].weight <= capacity)
        {
            totalProfit += items[i].profit;
            capacity -= items[i].weight;
        }
        else
        {
            totalProfit += items[i].ratio * capacity;
            capacity = 0;
        }
    }

    cout << "\nMaximum Profit = " << totalProfit;

    return 0;
}
