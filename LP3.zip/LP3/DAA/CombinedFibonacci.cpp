#include <iostream>
using namespace std;

// Non-Recursive Function
void fibonacciNonRecursive(int n)
{
    int a = 0, b = 1, c;

    cout << "\nNon-Recursive Series: ";

    for (int i = 1; i <= n; i++)
    {
        cout << a << " ";
        c = a + b;
        a = b;
        b = c;
    }
}

// Recursive Function to find nth Fibonacci number
int fibonacciRecursive(int n)
{
    if (n <= 1)
        return n;

    return fibonacciRecursive(n - 1) +
           fibonacciRecursive(n - 2);
}

// Function to print series recursively
void printRecursiveSeries(int n)
{
    cout << "\nRecursive Series: ";

    for (int i = 0; i < n; i++)
    {
        cout << fibonacciRecursive(i) << " ";
    }
}

int main()
{
    int n;

    cout << "Enter number of terms: ";
    cin >> n;

    if (n <= 0)
    {
        cout << "Invalid input";
        return 0;
    }

    fibonacciNonRecursive(n);
    printRecursiveSeries(n);

    return 0;
}
