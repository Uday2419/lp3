
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

int N;
vector<vector<char>> board;

// Check safe position
bool isSafe(int row, int col) {

    for (int i = 0; i < N; i++) {

        for (int j = 0; j < N; j++) {

            if (board[i][j] == 'Q') {

                if (i == row || j == col ||
                    abs(i - row) == abs(j - col)) {
                    return false;
                }
            }
        }
    }

    return true;
}

// Backtracking method
bool solve(int row, int fixedRow) {

    if (row == N)
        return true;

    if (row == fixedRow)
        return solve(row + 1, fixedRow);

    for (int col = 0; col < N; col++) {

        if (isSafe(row, col)) {

            board[row][col] = 'Q';

            if (solve(row + 1, fixedRow))
                return true;

            board[row][col] = '.';
        }
    }

    return false;
}

// Print board
void printBoard() {

    cout << "\nFinal N-Queens Board:\n";

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            cout << board[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {

    cout << "Enter value of N: ";
    cin >> N;

    if (N <= 0) {
        cout << "Invalid N!";
        return 0;
    }

    board.resize(N, vector<char>(N, '.'));

    cout << "Enter first queen row (0 to " << N-1 << "): ";
    int row;
    cin >> row;

    cout << "Enter first queen column (0 to " << N-1 << "): ";
    int col;
    cin >> col;

    if (row < 0 || row >= N || col < 0 || col >= N) {
        cout << "Invalid position!";
        return 0;
    }

    board[row][col] = 'Q';

    if (solve(0, row))
        printBoard();
    else
        cout << "No solution possible!";

    return 0;
}
